
package employee.payroll.management.system;

public class EmployeePayrollManagementSystem {

    
    public static void main(String[] args) {
        
    }
    
}
